/* gmp-ops.h: header private to npgmp.c.  */
OP (roll)
OP (pick)
OP (drop)
OP (quote)
#undef OP
