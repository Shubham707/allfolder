<?php 
include_once('common.php');
page_protect();
if(!isset($_SESSION['user_id']))
{
    logout();
}
$error = array();
$transactionList = array();
$user_session = $_SESSION['user_session'];
$user_current_balance = 0;
if(isset($_GET['nad']))
{
    $new_address = $_GET['nad'];
}
$client = "";
if(_LIVE_)
{
    $client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
    if(isset($client))
    {
        $transactionList = $client->getTransactionList($user_session);
        $user_current_balance = $client->getBalance($user_session) - $fee;
    }
}
?>
<?php
	include 'header.php';
?>

<div class="container-fluid">
	<div class="animated fadeIn">
		
        <div class="card marginTop25">
            <div class="card-header bg-success">
                <i class="fa fa-align-justify"></i> Transaction<br><br>
               
				    <a type="button" href="transactions.php" class="btn btn-white" id="Type_All">All</a>
					<a type="button" href="sent.php" class="btn btn-default" id="Type_Sent">Sent</a>
					<a type="button" href="recieved.php" class="btn btn-default" id="Type_Receive">Received</a>
				
            </div>
            <div class="card-body">
                <table class="table table-responsive table-hover table-outline mb-0">
                    <thead class="thead-default">
                        <tr>					
                             <th>Date</th>
                            <th>Address</th>
                            <th class="text-center">Type</th>
                            <th>Amount</th>
                            <th class="text-center">Confirmations</th>
                            <th>TX</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						      $bold_txxs = "";
                               if(count($transactionList)>0)
                                {
                                   foreach($transactionList as $transaction) 
                                   {
                                        if($transaction['category']=="send")
                                        {
                                            $tx_type = '<b style="color: #FF0000;">Sent</b>'; 
                                            echo '<tr>
                                               <td>'.date('n/j/Y h:i a',$transaction['time']).'</td>
                                               <td>'.$transaction['address'].'</td>
                                               <td>'.$tx_type.'</td>
                                               <td>'.abs($transaction['amount']).'</td>
                                               <td>'.$transaction['confirmations'].'</td>
                                               <td colspan=\"3\"><a href="' . $blockchain_url,  $transaction['txid'] . '" target="_blank">Info</a></td>
                                            </tr>';
                                        }
                                   }
                                }
                                else if((count($transactionList)== 0))
                                {
                                    echo "<tr><td colspan=\"3\">There is no Transaction exists</td><td></td><td></td><td></td></tr>";
                                }
                        ?>
					</tbody>
                </table>
            </div>
        </div> 
    </div>

    
    <!--/.row-->
</div>
	   

<?php
	include 'footer.php';
?>