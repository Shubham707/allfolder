<?php
        include_once('common.php');
        page_protect();
        if(!isset($_SESSION['user_id']))
        {
            logout();
        }
        $user_session = $_SESSION['user_session'];
        $error = array();
        $addressList = array();
        $new_address = "";
        $user_email= $user_session;
        $user_current_balance = 0;
        if(isset($_GET['nad']))
        {
            $new_address = $_GET['nad'];
        
        }
        $client = "";
        if(_LIVE_)
        {
            $client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
            if(isset($client))
            {
                //echo "<pre> dd </br>";var_dump($_SESSION);echo "</br> ddd <pre>";
                $addressList = $client->getAddressList($user_session);
                $user_current_balance = $client->getBalance($user_session) - $fee;
                
            }
        }


    /* block.io php */
         $block_io = new BlockIo($apiKey, $pin, $version);

         /* ---------------get block.io balance---------- */
        $getAddressBalance = $block_io->get_address_balance(array('labels' => $user_session));

        $balance_encode = json_encode($getAddressBalance);
        $balance = json_decode($balance_encode);
        $userBTCBalance = $balance->data->balances[0]->available_balance;
        

        /*----------------get address ------------------*/
       
        $getBTCAddress = $getAddressBalance = $block_io->get_address_balance(array('labels' => $user_session));
        
        $address_encode = json_encode($getBTCAddress);
        $address = json_decode($address_encode);
        $userBTCaddress = $address->data->balances[0]->address; 

        /*----------------get current BTC price in USD -----------*/ 
         // $currentPrice = $block_io->get_current_price(array('price_base' => 'USD'))->data->prices[0]->price;

        
         /*---------------get sent BTC transaction -------------*/
        $trans = $block_io->get_transactions(array('type' => 'sent', 'addresses' => $userBTCaddress));

        $son = json_encode($trans->data->txs, true);
        $array = json_decode($son, true);

        
        /*---------------get received BTC transaction -------------*/
        $trans2 =  $block_io->get_transactions(array('type' => 'received', 'addresses' => $userBTCaddress));
        $son2 = json_encode($trans2->data->txs, true);    
        $array2 = json_decode($son2, true);

         function convertDateTime($unixTime) {
           $dt = new DateTime("@$unixTime");
           return $dt->format('Y-m-d H:i:s');
        }

        
        

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="BCC wallet">
    <meta name="author" content="Bitcoin cash Foundation">
    <meta name="keyword" content="BCC Wallet, bitcoin cash, bitcoin, wallet, bcc, bch, btc bch">
    <link rel="shortcut icon" href="img/favicon.png">
    <title>Wallets | <?php echo $coin_fullname;?>(<?php echo $coin_short;?>)</title>

    <!-- Icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/simple-line-icons.css" rel="stylesheet">

    <!-- Main styles for this application -->
    <link href="css/style.css" rel="stylesheet">
</head>


<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
    <header class="app-header navbar">
        <button class="navbar-toggler mobile-sidebar-toggler d-lg-none mr-auto" type="button">&#9776;</button>
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler sidebar-minimizer d-md-down-none" type="button">&#9776;</button>

        <ul class="nav navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-user"></i>
                    <span class="d-md-down-none"><?php echo $user_email;?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">

                    <a class="dropdown-item" href="securitycenter.php"><i class="fa fa-lock"></i> Security</a>
                    <a class="dropdown-item" href="contactus.php"><i class="fa fa-lock"></i> Contact</a>
                    <a class="dropdown-item" href="logout.php"><i class="fa fa-lock"></i> Logout</a>
                        <!-- admin access -->
                    <?php 
                        if($_SESSION['user_admin'] == 1)
                        {
                        ?>
                            <a href="admin_user.php"><!--<i class="zmdi zmdi-help-outline iconFAQ" style=""></i>-->User list</a>
                        <?php
                    }
                    ?>  
                </div>
            </li>
        </ul>
        <!-- <button class="navbar-toggler aside-menu-toggler" type="button">&#9776;</button> -->

    </header>

    <div class="app-body">
        <div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                    <li class="nav-title">
                        BCH Vault
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="icon-speedometer"></i> Dashboard <span class="badge badge-primary">NEW</span></a>
                    </li>

                    
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link " href="myaddress.php"><i class="fa fa-address-card-o"></i> Myaddress</a>
                    </li>
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link" href="transactions.php"><i class="fa fa-list-alt"></i> Transactions</a>
                    </li>
                    <li class="nav-title">
                        BTC Vault 
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="getbch.php"><i class="fa fa-exchange"></i> Get BCH <span class="badge badge-primary">NEW</span></a>
                    </li>
                    
                    <li class="divider"></li>
                    <li class="nav-title">
                        Extras
                    </li>
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link" href="contactus.php"><i class="fa fa-phone"></i> Contact US</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="securitycenter.php"><i class="fa fa-lock"></i> Security Center</a>
                    </li>
                    <?php 
                        if($_SESSION['user_admin'] == 1)
                        {
                        ?>
                            <li id="ms6"><a href="admin_user.php" class="collapsible-header"><!--<i class="zmdi zmdi-help-outline iconFAQ" style=""></i>-->User list</a></li>
                        <?php

                        }
                    ?>  
                </ul>
            </nav>
        </div>

        <!-- Main content -->
        <main class="main">

            <!-- Breadcrumb -->
            <ol class="breadcrumb visible-xs">

                <!-- Breadcrumb Menu-->
                <li class="breadcrumb-menu breadcrumb-item ">
                    <div class="btn-group" role="group" aria-label="Button group">
                        <a class="btn" href="send.php" id="btnsend"><i class="fa fa-sign-out"></i>&nbsp;Send BCH</a>
                        <a class="btn" href="recievecoin.php" id="btnreceived"><i class="fa fa-sign-in"></i>&nbsp;Receive BCH</a>
                        <a class="btn" href="./" ><i class="icon-graph"></i> &nbsp;<?php echo $user_current_balance." " . $coin_short;?></a>
                        
                    </div>
                </li>
            </ol>
