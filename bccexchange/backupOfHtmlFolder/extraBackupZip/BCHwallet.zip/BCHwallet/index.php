<?php 
	include_once('common.php');
	page_protect();
	if(!isset($_SESSION['user_id']))
	{
		logout();
	}
	$user_session = $_SESSION['user_session'];
	$error = array();
	$transactionList = array();
	
	$user_current_balance = 0;
	if(isset($_GET['nad']))
	{
		$new_address = $_GET['nad'];
	}
	$client = "";
	if(_LIVE_)
	{
		$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
		if(isset($client))
		{
			$transactionList = $client->getTransactionList($user_session);
			$user_current_balance = $client->getBalance($user_session) - $fee;
		}
	}
?>
<?php
	include 'header.php';
?>
	<div class="container-fluid">
		<div class="animated fadeIn">
		    <div class="row">
		        <div class="col-md-8">
		            <div class="card d-md-down-none ">
		                <div class="card-header bg-success">
		                    Bitcoin / Bitcoin Cash Chart (BTC/BCH)
		                </div>
		                <div class="card-body">
		                     
							<!-- TradingView Widget BEGIN -->
							<div id="tv-medium-widget-6ebf0"></div>
							<script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
							<script type="text/javascript">
								new TradingView.MediumWidget({
								  "container_id": "tv-medium-widget-6ebf0",
								  "symbols": [
								    "BITFINEX:BCHBTC|1d"
								  ],
								  "gridLineColor": "#e9e9ea",
								  "fontColor": "#83888D",
								  "underLineColor": "#dbeffb",
								  "trendLineColor": "rgba(56, 118, 29, 1)",
								  "width": "750px",
								  "height": "500px",
								  "locale": "in"
								});
							</script>
							<!-- TradingView Widget END -->

		                    <!--/.row-->
		                    <br/>
		                    
					        <!--/.col-->
					    </div>
					    <!--/.row-->
					</div>
				</div> 
				<div class="col-md-4">
					<div class="card text-white bg-success">
		                <div class="card-header text-center">
		                    <div class="h4"><?php echo $userBTCBalance ?> BTC</div>
			                 

			            </div>
		                <div class="card-body text-center bg-white text-success">
		                    <img src="http://chart.apis.google.com/chart?cht=qr&chs=300x300&chl=<?php echo $myAddress?>" 
													alt="QR Code" style="width:150px;border:0;"><br>
							<span><?php echo $userBTCaddress; ?></span> 
		                </div>
		            </div>
		            <div class="card text-white bg-success">
		                
		                <div class="card-body bg-white text-center text-success">

		                    <span>
			                	<?php 
				                	if($_SESSION['is_email_verify'] == 1){
				                		 echo "<span class=\"text-success\"><i class=\"fa fa-check-circle fa-5x\"></i>" ;
				                		}
				                	 else { 
				                	 	echo "<span class=\"text-danger\"><i class=\"fa fa-warning fa-5x\"></i>" ; 
				                	 	} 
		                    	?><br>
		                    	<?php 
		                    	 	if($_SESSION['is_email_verify'] == 0){
		                    	 		echo "<a type=\"button\"   class=\"btn btn-danger\" href=\"securitycenter.php\">
								    		 Not Verified?
											</a>";
										}
									else { 
				                	 	echo "<span>Verified" ; 
				                	 	} 	
								?>
							</span>
		                </div>
		            </div> 
				</div>   
			</div>
			
            <div class="card">
               <div class="card-header bg-success">
	                <i class="fa fa-align-justify"></i> Transaction<br><br>
	               
					
	            </div>
               
	            <div class="card-body">
	                <table class="table table-responsive table-hover table-outline mb-0">
	                    <thead class="thead-default">
	                        <tr>					
	                             <th>Date</th>
	                            <th>Address</th>
	                            <th class="text-center">Type</th>
	                            <th>Amount</th>
	                            <th class="text-center">Confirmations</th>
	                            <th>TX</th>
	                        </tr>
	                    </thead>
	                    <tbody>
							<?php
								$bold_txxs = "";
							   if(count($transactionList)>0)
								{
								   foreach($transactionList as $transaction) {
									  if($transaction['category']=="send") { $tx_type = '<b style="color: #FF0000;">Sent</b>'; } else { $tx_type = '<b style="color: #01DF01;">Received</b>'; }
									  echo '<tr>
											   <td>'.date('n/j/Y h:i a',$transaction['time']).'</td>
											   <td>'.$transaction['address'].'</td>
											   <td>'.$tx_type.'</td>
											   <td>'.abs($transaction['amount']).'</td>
											   <td>'.$transaction['confirmations'].'</td>
											   <td colspan=\"3\"><a href="' . $blockchain_url,  $transaction['txid'] . '" target="_blank">Info</a></td>
											</tr>';
								   }
								}
								else if((count($transactionList)== 0))
								{
									echo "<tr><td>There is no Transaction exists</td><td></td><td></td><td></td><td></td><td></td></tr>";
								}
							?>	
						</tbody>
	                </table>
	            </div>
            </div>
		        
		</div>
	</div>

<?php
	include 'footer.php';
?>