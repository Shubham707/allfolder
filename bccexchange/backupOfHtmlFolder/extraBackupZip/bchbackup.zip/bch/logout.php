<?php
	include_once('wallet/common.php');
	logout();
?> 