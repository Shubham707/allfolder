<html xmlns="http://www.w3.org/1999/html">
 <h1>An Email has been Successfully send to your email id.</h1>
</br>

<a href="landingpage.php"> Back to login</a>
</html>