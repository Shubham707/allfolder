<footer class="ln-footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-2">
        <img src="img/logo.png"" alt="footer-logo" width="157px;">
        <p class="ln-copright" style="color: white !important">©Copyright 2017</p>
        <p class="ln-copright" style="color: white !important">All Rights Reserved</p>

        
      </div>
      <div class="col-sm-2">
        
       
        <ul> <h4 class="ln-copright">OUR SERVICES</h4>
          <li><a href="#">Regular Services</a></li>
          <li><a href="#">Buy Bitcoin</a></li>
          <li><a href="#">Sell Bitcoin</a></li>
          <li><a href="#">Exchange Bitcoin</a></li>
        </ul>
      </div>
      <div class="col-sm-2">
        
        
        <ul><h4 class="ln-copright">TOOLS</h4>
          <li><a href="#">API</a></li>
          <li><a href="#">Bitcoin Calculator</a></li>
          <li><a href="#">Bitcoin Price Widget</a></li>
          <li><a href="#">Donations</a></li>
        </ul>
      </div>
      <div class="col-sm-2">
        
        
          <ul><h4 class="ln-copright">ABOUT</h4>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Legal & Security</a></li>
          <li><a href="#">Terms of Use</a></li>
          <li><a href="#">Refund Policy</a></li>
          <li><a href="#">Blog</a></li>
        </ul>

        
      </div>
      <div class="col-sm-2">
        
       
         <ul> <h4 class="ln-copright">FOLLOW US ON</h4>
          <li></i>Facebook</li>
          <li><a href="#">Gmail</a></li>
          <li><a href="#">Twitter</a></li>
          <li><a href="#">Instagram</a></li>

        </ul>

        
      </div>
      <div class="col-sm-2">
        
        <h4 class="ln-copright">OUR NEWSLETTER</h4>
        <p style="color: white !important">Get Latest Updates From Our Newsletter</p>
        <div class="input-group">
         <input type="text" class="form-control" placeholder="E-mail" aria-describedby="basic-addon2">
         
        </div>
      </div>
      
    </div>
 
  </div>
</footer>


    


    
<script src="./assets/deps.min.js"></script>
<script src="./assets/website.js"></script>
<script>
  initPageBanner();
  initNavScroll();
  initSideNav();
  initForms();
  initFooter();
  LunoAuth.auth();
</script>

<script type="text/javascript">_linkedin_data_partner_id = "72903";</script>
<script type="text/javascript">(function(){var s = document.getElementsByTagName("script")[0]; var b = document.createElement("script"); b.type = "text/javascript";b.async = true; b.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js"; s.parentNode.insertBefore(b, s);})();</script>
<noscript>&lt;img height="1" width="1" style="display:none;" alt="" src="https://dc.ads.linkedin.com/collect/?pid=72903&amp;fmt=gif"&gt;</noscript>


    
<script>
  initIndexPage();
  initEasySteps();
</script>


<script src="./assets/saved_resource" type="text/javascript"></script><script src="./assets/saved_resource(1)" type="text/javascript"></script></body></html>