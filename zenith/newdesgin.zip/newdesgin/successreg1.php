<html xmlns="http://www.w3.org/1999/html">
 <h1>Successfully login</h1>
</br>

<a href="index.php">Go Back to Home</a>
</html>