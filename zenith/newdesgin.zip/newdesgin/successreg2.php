<html xmlns="http://www.w3.org/1999/html">
 <h1>Successfully login In Exchnage</h1>
</br>

<a href="exchangebuybtg.php">Go Back to Home</a>
</html>