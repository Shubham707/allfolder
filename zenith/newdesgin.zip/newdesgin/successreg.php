<html xmlns="http://www.w3.org/1999/html">
 <h1>Successfully Signup</h1>
</br>

<a href="landingpage.php">Go Back to Home</a>
</html>